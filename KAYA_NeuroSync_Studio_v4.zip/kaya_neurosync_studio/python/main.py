import os
import collections
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier

from arduino.app_utils import App, Bridge, Logger
from arduino.app_bricks.web_ui import WebUI

logger = Logger("NeuroSync")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_PATH = os.path.join(DATA_DIR, "model.joblib")
DATASET_PATH = os.path.join(DATA_DIR, "dataset.joblib")
os.makedirs(DATA_DIR, exist_ok=True)

FEATURE_WINDOW_SIZE = 125  # 500 ms @ 250 Hz
feature_data_buffer = collections.deque(maxlen=FEATURE_WINDOW_SIZE)

baseline_dc = 0.0
baseline_rms = 0.05
sensor_active = True

# Class-wise dataset counter [0: Neutral, 1: Left, 2: Right, 3: Jaw Clench]
class_counts = {0: 1, 1: 1, 2: 1, 3: 1}

# Initialize persistent dataset
if os.path.exists(DATASET_PATH):
    X_dataset, y_dataset = joblib.load(DATASET_PATH)
    for lbl in [0, 1, 2, 3]:
        class_counts[lbl] = int(np.sum(y_dataset == lbl))
else:
    X_dataset = np.array([
        [0.00, 0.00, 0.10],   # Neutral
        [-0.40, 0.02, 0.80],  # Left Eye
        [0.40, 0.02, 0.80],   # Right Eye
        [0.00, 0.35, 1.20]    # Jaw Clench
    ])
    y_dataset = np.array([0, 1, 2, 3])
    joblib.dump((X_dataset, y_dataset), DATASET_PATH)

# Initialize model
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)
else:
    model = RandomForestClassifier(n_estimators=25, warm_start=True, random_state=42)
    model.fit(X_dataset, y_dataset)
    joblib.dump(model, MODEL_PATH)

latest_telemetry = {
    "dc_offset": 0.0,
    "rel_dc": 0.0,
    "rms": 0.0,
    "rel_rms": 0.0,
    "v_pp": 0.0,
    "prediction": 0,
    "emergency": False,
    "instant_raw": 0.0,
    "sensor_active": True,
    "class_counts": class_counts,
    "total_samples": len(y_dataset),
    "accuracy": 0.0,
    "importances": [33.3, 33.3, 33.4],
    "model_status": "READY"
}

def extract_features(window):
    arr = np.array(window)
    raw_dc = float(np.mean(arr))
    raw_rms = float(np.sqrt(np.mean(arr**2)))
    v_pp = float(np.ptp(arr))
    return [raw_dc - baseline_dc, max(0.0, raw_rms - baseline_rms), v_pp], raw_dc, raw_rms

def handle_adc_batch(*args):
    global latest_telemetry
    if not args or not sensor_active:
        return
    
    batch = args[0] if isinstance(args[0], (list, tuple)) else list(args)
    
    for sample in batch:
        feature_data_buffer.append(sample)
    
    latest_telemetry["instant_raw"] = round(float(batch[-1]), 4)

    if len(feature_data_buffer) == FEATURE_WINDOW_SIZE:
        feats, raw_dc, raw_rms = extract_features(feature_data_buffer)
        prediction = int(model.predict([feats])[0])
        is_emergency = bool(prediction == 3 or feats[1] > 0.25)

        latest_telemetry.update({
            "dc_offset": round(raw_dc, 4),
            "rel_dc": round(feats[0], 4),
            "rms": round(raw_rms, 4),
            "rel_rms": round(feats[1], 4),
            "v_pp": round(feats[2], 4),
            "prediction": prediction,
            "emergency": is_emergency,
        })

Bridge.provide("process_adc_batch", handle_adc_batch)

web_ui = WebUI()

def get_telemetry():
    latest_telemetry["sensor_active"] = sensor_active
    latest_telemetry["class_counts"] = class_counts
    latest_telemetry["total_samples"] = len(y_dataset)
    return latest_telemetry

def toggle_sensor():
    global sensor_active
    sensor_active = not sensor_active
    latest_telemetry["sensor_active"] = sensor_active
    return {"status": "success", "sensor_active": sensor_active}

def calibrate_baseline():
    global baseline_dc, baseline_rms
    if len(feature_data_buffer) == FEATURE_WINDOW_SIZE:
        arr = np.array(feature_data_buffer)
        baseline_dc = float(np.mean(arr))
        baseline_rms = float(np.sqrt(np.mean(arr**2)))
        return {"status": "success", "baseline_dc": round(baseline_dc, 4)}
    return {"status": "error"}

def record_sample(data: dict):
    global X_dataset, y_dataset, class_counts
    label = data.get("label")
    if label is not None and len(feature_data_buffer) == FEATURE_WINDOW_SIZE:
        feats, _, _ = extract_features(feature_data_buffer)
        X_dataset = np.vstack([X_dataset, feats])
        y_dataset = np.append(y_dataset, label)
        class_counts[label] += 1
        joblib.dump((X_dataset, y_dataset), DATASET_PATH)
        return {"status": "success", "class_counts": class_counts}
    return {"status": "error", "message": "Buffer warming up"}

def train_model():
    global model, latest_telemetry
    if len(y_dataset) > 0:
        model.n_estimators += 2
        model.fit(X_dataset, y_dataset)
        joblib.dump(model, MODEL_PATH)
        
        acc = float(model.score(X_dataset, y_dataset) * 100)
        imps = model.feature_importances_.tolist() if hasattr(model, "feature_importances_") else [0.33, 0.33, 0.34]
        
        latest_telemetry.update({
            "accuracy": round(acc, 1),
            "importances": [round(f * 100, 1) for f in imps],
            "model_status": "TRAINED & PERSISTED"
        })
        return {"status": "success", "accuracy": round(acc, 1)}
    return {"status": "error"}

web_ui.expose_api("GET", "/api/telemetry", get_telemetry)
web_ui.expose_api("POST", "/api/toggle_sensor", toggle_sensor)
web_ui.expose_api("POST", "/api/calibrate", calibrate_baseline)
web_ui.expose_api("POST", "/api/record", record_sample)
web_ui.expose_api("POST", "/api/train_model", train_model)

if __name__ == "__main__":
    App.run()