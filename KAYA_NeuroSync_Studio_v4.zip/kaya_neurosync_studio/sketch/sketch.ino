#include "Arduino_RouterBridge.h"
#include <array>

#define ADC_PIN A0
#define SAMPLE_RATE_HZ 250
#define SAMPLE_INTERVAL_US (1000000 / SAMPLE_RATE_HZ)
#define BATCH_SIZE 25 // 10 Hz RPC dispatch rate

// 2nd-Order Direct Form II IIR Notch Filter (fs = 250 Hz, f0 = 50 Hz, Q = 30)
const float b0 = 0.958827f, b1 = -0.592562f, b2 = 0.958827f;
const float a1 = -0.592562f, a2 = 0.917654f;

float w1 = 0.0f, w2 = 0.0f;
unsigned long lastSampleTime = 0;

std::array<float, BATCH_SIZE> batchBuffer;
uint8_t batchIndex = 0;

inline float filterSample(float x) {
    float w0 = x - a1 * w1 - a2 * w2;
    float y = b0 * w0 + b1 * w1 + b2 * w2;
    w2 = w1; w1 = w0;
    return y;
}

void setup() {
    Bridge.begin();
    analogReadResolution(14);
    pinMode(ADC_PIN, INPUT);
    lastSampleTime = micros();
}

void loop() {
    unsigned long now = micros();
    if (now - lastSampleTime >= SAMPLE_INTERVAL_US) {
        lastSampleTime += SAMPLE_INTERVAL_US;

        uint16_t rawAdc = analogRead(ADC_PIN);
        float voltage = (rawAdc / 16383.0f) * 3.3f;
        
        batchBuffer[batchIndex++] = filterSample(voltage);

        if (batchIndex >= BATCH_SIZE) {
            Bridge.notify("process_adc_batch", batchBuffer);
            batchIndex = 0;
        }
    }
}