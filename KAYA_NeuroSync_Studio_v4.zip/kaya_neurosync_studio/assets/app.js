const gridCanvas = document.getElementById('bci-canvas');
const gridCtx = gridCanvas.getContext('2d');

const rawValElement = document.getElementById('instant-raw-val');
const signalLevelBar = document.getElementById('signal-level-bar');
const sensorToggleBtn = document.getElementById('sensor-toggle-btn');

const elDc = document.getElementById('val-dc');
const elRms = document.getElementById('val-rms');
const elVpp = document.getElementById('val-vpp');
const elPred = document.getElementById('val-pred');
const elEmergency = document.getElementById('emergency-badge');

const elMlSamples = document.getElementById('ml-samples');
const elMlAccVal = document.getElementById('ml-acc-val');
const elMlAccBar = document.getElementById('ml-acc-bar');
const elMlStatusLbl = document.getElementById('ml-status-lbl');

const cnt0 = document.getElementById('cnt-0');
const cnt1 = document.getElementById('cnt-1');
const cnt2 = document.getElementById('cnt-2');
const cnt3 = document.getElementById('cnt-3');

const elFiDcBar = document.getElementById('fi-dc-bar');
const elFiRmsBar = document.getElementById('fi-rms-bar');

let selectedIndex = 0;
let lastNavTime = 0;
let isFetching = false;

const gridOptions = [
    "WATER", "NURSE HELP", "POSITION", "PAIN RELIEF",
    "LIGHTS TOGGLE", "ENTERTAINMENT", "FAMILY CALL", "EMERGENCY CLEAR"
];

function renderGrid(activeIndex, isEmergency) {
    gridCtx.clearRect(0, 0, gridCanvas.width, gridCanvas.height);
    const cols = 4, rows = 2;
    const cellW = gridCanvas.width / cols;
    const cellH = gridCanvas.height / rows;

    gridOptions.forEach((opt, i) => {
        const x = (i % cols) * cellW + 8;
        const y = Math.floor(i / cols) * cellH + 8;
        const w = cellW - 16, h = cellH - 16;
        const isActive = (i === activeIndex);

        gridCtx.fillStyle = (isEmergency && isActive) ? '#7f1d1d' : (isActive ? '#0f384c' : '#111827');
        gridCtx.beginPath();
        gridCtx.roundRect(x, y, w, h, 8);
        gridCtx.fill();

        gridCtx.lineWidth = isActive ? 4 : 1;
        gridCtx.strokeStyle = isActive ? (isEmergency ? '#ef4444' : '#00f3ff') : '#374151';
        gridCtx.stroke();

        gridCtx.fillStyle = isActive ? '#ffffff' : '#9ca3af';
        gridCtx.font = isActive ? 'bold 18px Consolas' : '15px Consolas';
        gridCtx.textAlign = 'center';
        gridCtx.textBaseline = 'middle';
        gridCtx.fillText(opt, x + w / 2, y + h / 2);
    });
}

async function toggleSensor() {
    try {
        const res = await fetch('/api/toggle_sensor', { method: 'POST' });
        const data = await res.json();
        updateSensorBtn(data.sensor_active);
    } catch (e) {}
}

function updateSensorBtn(active) {
    if (active) {
        sensorToggleBtn.textContent = "SENSOR: ON";
        sensorToggleBtn.className = "toggle-btn active";
    } else {
        sensorToggleBtn.textContent = "SENSOR: OFF";
        sensorToggleBtn.className = "toggle-btn inactive";
    }
}

async function calibrateBaseline() {
    try { await fetch('/api/calibrate', { method: 'POST' }); } catch (e) {}
}

async function recordSample(labelId) {
    try {
        await fetch('/api/record', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ label: labelId })
        });
    } catch (e) {}
}

async function triggerModelTrain() {
    try {
        elMlStatusLbl.textContent = "TRAINING...";
        const res = await fetch('/api/train_model', { method: 'POST' });
        const data = await res.json();
        if (data.status === "success") {
            elMlAccVal.textContent = data.accuracy.toFixed(1) + "%";
            elMlAccBar.style.width = data.accuracy + "%";
            elMlStatusLbl.textContent = "TRAINED & PERSISTED";
        }
    } catch (e) {
        elMlStatusLbl.textContent = "ERROR";
    }
}

async function updateTelemetry() {
    if (isFetching) return;
    isFetching = true;

    try {
        const res = await fetch('/api/telemetry');
        if (res.ok) {
            const data = await res.json();

            rawValElement.textContent = data.instant_raw.toFixed(3) + ' V';
            const intensityPct = Math.min(100, Math.max(0, (data.instant_raw / 3.3) * 100));
            signalLevelBar.style.width = intensityPct + '%';

            elDc.textContent = data.rel_dc.toFixed(3) + ' V';
            elRms.textContent = data.rel_rms.toFixed(3) + ' V';
            elVpp.textContent = data.v_pp.toFixed(3) + ' V';

            updateSensorBtn(data.sensor_active);

            if (data.class_counts) {
                cnt0.textContent = data.class_counts[0] || 0;
                cnt1.textContent = data.class_counts[1] || 0;
                cnt2.textContent = data.class_counts[2] || 0;
                cnt3.textContent = data.class_counts[3] || 0;
            }
            elMlSamples.textContent = data.total_samples;

            if (data.accuracy !== undefined) {
                elMlAccVal.textContent = data.accuracy.toFixed(1) + "%";
                elMlAccBar.style.width = data.accuracy + "%";
            }
            if (data.importances) {
                elFiDcBar.style.width = data.importances[0] + "%";
                elFiRmsBar.style.width = data.importances[1] + "%";
            }

            // ML Navigation Logic
            const now = Date.now();
            if (now - lastNavTime > 400 && data.sensor_active) {
                if (data.prediction === 1) {
                    selectedIndex = (selectedIndex - 1 + gridOptions.length) % gridOptions.length;
                    lastNavTime = now;
                } else if (data.prediction === 2) {
                    selectedIndex = (selectedIndex + 1) % gridOptions.length;
                    lastNavTime = now;
                }
            }

            if (data.emergency || data.prediction === 3) {
                elEmergency.classList.remove('hidden');
                elPred.textContent = "EMERGENCY CLENCH";
                renderGrid(selectedIndex, true);
            } else {
                elEmergency.classList.add('hidden');
                const stateNames = ["NEUTRAL", "EOG LEFT", "EOG RIGHT", "JAW CLENCH"];
                elPred.textContent = stateNames[data.prediction] || "UNKNOWN";
                renderGrid(selectedIndex, false);
            }
        }
    } catch (err) {
    } finally {
        isFetching = false;
    }
}

renderGrid(selectedIndex, false);
setInterval(updateTelemetry, 100);